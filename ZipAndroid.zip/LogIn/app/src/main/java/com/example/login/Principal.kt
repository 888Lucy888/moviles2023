package com.example.login

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.login.databinding.ActivityPrincipalBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.*
import com.google.firebase.ktx.Firebase
import com.google.zxing.integration.android.IntentIntegrator

class Principal : AppCompatActivity() {
    private lateinit var binding: ActivityPrincipalBinding
    private lateinit var auth: FirebaseAuth
    private val clavesRef = FirebaseDatabase.getInstance().reference.child("claves")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPrincipalBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.scannear.setOnClickListener { initScanner() }

        auth = Firebase.auth
    }

    private fun initScanner() {
        IntentIntegrator(this).initiateScan()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            if (result.contents == null) {
                Toast.makeText(this, "Cancelado", Toast.LENGTH_SHORT).show()
            } else {
                compararCodigoFirebase(result.contents)
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun compararCodigoFirebase(codigo: String) {
        clavesRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val codigosExistentes = dataSnapshot.children.mapNotNull { it.key as? String }
                val codeFound = codigosExistentes.contains(codigo)

                if (codeFound) {
                    val statusRef = clavesRef.child(codigo).child("status")
                    statusRef.addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            val status = snapshot.value as? String
                            if (status == "disponible") {
                                // Code is available
                                statusRef.setValue("canjeado")
                                    .addOnSuccessListener {
                                        Toast.makeText(this@Principal, "Código canjeado correctamente", Toast.LENGTH_SHORT).show()
                                    }
                                    .addOnFailureListener {
                                        Toast.makeText(this@Principal, "Error al canjear el código", Toast.LENGTH_SHORT).show()
                                    }
                            } else {
                                // Code is not available
                                Toast.makeText(this@Principal, "Código no disponible, ya ha sido canjeado", Toast.LENGTH_SHORT).show()
                            }
                        }

                        override fun onCancelled(error: DatabaseError) {
                            Toast.makeText(this@Principal, "Error en la consulta: ${error.message}", Toast.LENGTH_SHORT).show()
                        }
                    })
                } else {
                    Toast.makeText(this@Principal, "Código no encontrado", Toast.LENGTH_SHORT).show()

                    val codigosString = codigosExistentes.joinToString(", ")

                    Toast.makeText(
                        this@Principal,
                        "\nCódigos existentes: $codigosString",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Toast.makeText(this@Principal, "Error en la consulta: ${databaseError.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }


}
