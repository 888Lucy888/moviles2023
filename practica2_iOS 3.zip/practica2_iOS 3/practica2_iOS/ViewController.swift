//
//  ViewController.swift
//  practica2_iOS
//
//  Created by Alumno on 24/03/23.
//

import UIKit
import FirebaseAuth

class ViewController: UIViewController {

    @IBOutlet weak var user: UITextField!
    
    @IBOutlet weak var pswd: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func login(_ sender: Any) {
        Auth.auth().signIn(withEmail: user.text ?? ""
                           , password: pswd.text ?? ""){
            (resultado, error) in
            if (error == nil){
                self.performSegue(withIdentifier: "aPrincipal", sender: self)
            } else {
                let alertError = UIAlertController(title: "Error", message: "Usuario o Contraseña incorrectos" + error!.localizedDescription, preferredStyle: .alert)
                alertError.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default))
                
                self.present(alertError, animated: true, completion: nil)
            }
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "aPrincipal"){
            let principal = segue.destination as? ViewControllerPrincipal
            
        }
    }
    
}

