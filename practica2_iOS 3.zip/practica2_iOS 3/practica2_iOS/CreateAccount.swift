//
//  CreateAccount.swift
//  practica2_iOS
//
//  Created by Alumno on 31/03/23.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase


class CreateAccount: UIViewController {

    let ref = Database.database().reference()
    
    @IBOutlet weak var userF: UITextField!
    
    @IBOutlet weak var pswdF: UITextField!
    
    @IBOutlet weak var nameF: UITextField!
    
    @IBOutlet weak var lastnameF: UITextField!
    
    @IBOutlet weak var careerF: UITextField!
    
    @IBOutlet weak var semesterF: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func createAccountB(_ sender: Any) {
        Auth.auth().createUser(withEmail: userF.text ?? "", password: pswdF.text ?? "") { (AuthDataResult, Error) in
            if (Error == nil){
                var usuario = AuthDataResult?.user
                if(usuario != nil){
                    self.ref.child("user").child(usuario!.uid).setValue(["career":self.careerF.text, "lastname":self.lastnameF.text, "name":self.nameF.text,   "semester":self.semesterF.text]) { (error, snapchop) in
                        if (error == nil){
                            let alertaexito  = UIAlertController(title: "Éxito", message: "Usuario registrado " + usuario!.uid, preferredStyle: .alert)
                            alertaexito.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default))
                            
                            self.present(alertaexito, animated: true, completion: nil)
                        } else {
                            let alertError = UIAlertController(title: "Error", message: "No registrado " + error!.localizedDescription, preferredStyle: .alert)
                            alertError.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default))
                            
                            self.present(alertError, animated: true, completion: nil)
                        }
                    }
                }
            } else {
                let alertError = UIAlertController(title: "Error", message: "No registrado " + Error!.localizedDescription, preferredStyle: .alert)
                alertError.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default))
                
                self.present(alertError, animated: true, completion: nil)
            }
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
