//
//  QRGenerator.swift
//  practica2_iOS
//
//  Created by Francisco Serna Villaseñor on 24/05/23.
//
import CoreImage.CIFilterBuiltins
import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class QRGenerator: UIViewController {
    
    let rootRef = Database.database().reference()
    

    @IBOutlet weak var codigo: UITextField!
    @IBOutlet weak var imageQR: UIImageView!
    
    let context = CIContext()
    let filter = CIFilter.qrCodeGenerator()
    let usuarioActual = Auth.auth().currentUser?.uid
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    
    @IBAction func generaCodigo(_ sender: Any) {
        let clavesRef = self.rootRef.child("claves")
            
            clavesRef.queryOrdered(byChild: "status").queryEqual(toValue: "no disponible").queryLimited(toFirst: 1).observe(.childAdded) { (snapshot) in
                self.codigo.text = snapshot.key
                snapshot.childSnapshot(forPath: "status").ref.setValue("disponible")
                snapshot.childSnapshot(forPath: "usuario").ref.setValue("noLigado")//(self.usuarioActual)
            }
        
        let cadena = codigo.text
        
        if(cadena != nil && cadena != ""){
            imageQR.image = generateQRCode(from: cadena!)
        }

    }
    
    func generateQRCode(from string: String) -> UIImage{
        filter.message = Data(string.utf8)
        
        let transforms = CGAffineTransform(scaleX: 10, y: 10)
        	
        if let outputImage = filter.outputImage?.transformed(by: transforms){
            if let cgimg = context.createCGImage(outputImage, from: outputImage.extent){
                return UIImage(cgImage: cgimg)
            }
        }
        
        return UIImage(systemName: "xmark.circle") ?? UIImage()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
