//
//  editaCuenta.swift
//  practica2_iOS
//
//  Created by Alumno on 28/04/23.
//

import UIKit

import FirebaseAuth
import FirebaseDatabase

class editaCuenta: UIViewController {

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var lastname: UITextField!
    @IBOutlet weak var career: UITextField!
    @IBOutlet weak var semester: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let ref = Database.database().reference()
        let usuarioActual = Auth.auth().currentUser
        
        ref.child("user").child(usuarioActual?.uid ?? "").getData {(
        Error, DataSnapshot) in
            if (Error == nil){
                self.name.text = (DataSnapshot?.childSnapshot(forPath: "name").value as? String)
                self.lastname.text = (DataSnapshot?.childSnapshot(forPath: "lastname").value as? String)
                self.career.text = (DataSnapshot?.childSnapshot(forPath: "career").value as? String)
                self.semester.text = (DataSnapshot?.childSnapshot(forPath: "semester").value as? String)
                
            }
            
        }
    }
    

    @IBAction func editAccount(_ sender: Any) {
        let usuarioActual = Auth.auth().currentUser
        let ref = Database.database().reference()
        
        ref.child("user").child(usuarioActual!.uid).setValue(["name":self.name.text ?? "", "lastname": self.lastname.text ?? "", "career": self.career.text ?? "", "semester": self.semester.text ?? ""], withCompletionBlock: {(error, snapchop) in
            
            if (error == nil){
                
                
                let alertaExito = UIAlertController(title: "Success!", message: "Account has been updated", preferredStyle: .alert)
                alertaExito.addAction(UIAlertAction(title: "Ok", style: .default))
                self.present(alertaExito, animated: true, completion: nil)
                
                
                                      
            } else {
                
                
                let alertaError = UIAlertController(title: "Error!", message: "The account has NOT been updated"+error!.localizedDescription, preferredStyle: .alert)
                alertaError.addAction(UIAlertAction(title: "Ok", style: .default))
                self.present(alertaError, animated: true, completion: nil)
                
            }
        })
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
