//
//  ViewControllerPrincipal.swift
//  practica2_iOS
//
//  Created by Alumno on 24/03/23.
//

import UIKit
import FirebaseAuth

class ViewControllerPrincipal: UIViewController {
    
    
    @IBOutlet weak var tableV: UITableView!
    
    let opciones = ["Editar cuenta","Generador de QR", "Salir"]
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableV.dataSource = self
        tableV.delegate = self

        // Do any additional setup after loading the view.
    }
    

   
    

}

extension ViewControllerPrincipal : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return opciones.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.accessoryType = .disclosureIndicator
        cell.textLabel?.text = opciones[indexPath.row]
        
        return cell
    }
}

extension ViewControllerPrincipal :UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if(indexPath.row == 0){
            performSegue(withIdentifier: "editaCuenta", sender: self)
        }
        else if (indexPath.row == 1){
            performSegue(withIdentifier: "qrgen", sender: self)
        }
        else{
            do{
                try Auth.auth().signOut()
                navigationController?.popViewController(animated: true)
            }catch{
                print("Ocurrió un error")
            }
        }
    }
}
